<?php
include 'header.php';
include 'includes/items.inc.php';
?>

<h1>Add New Item</h1>
<form method="post" enctype="multipart/form-data">
<?php echo $error; ?>
    <table class='table table-bordered table-hover'>
        <tr>
            <td>Product</td>
            <td><input type='text' name='name' class='form-control' maxlength="100" placeholder="Max Length 100" value="<?php echo $name; ?>" required /></td>
        </tr>
        <tr>
            <td>Description</td>
            <td><textarea type='text' name='description' class='form-control' placeholder="Max Length 255" value="<?php echo $description; ?>" required></textarea></td>
        </tr>
        <tr>
            <td>Price (&#36;)</td>
            <td>
				<!-- step="0.01" was used so that it can accept number with two decimal places -->
				<input type='number' step="0.01" name='price' class='form-control' value="<?php echo $price; ?>" required />
			</td>
        </tr>
		<tr>
		    <td>Photo</td>
		    <td><input type="file" name="img" accept="image/png,image/gif,image/jpeg,image/jpg"/></td>
		</tr>
        <tr>
            <td>Category</td>
            <td>
                <select class="dropdown-menu" name="category" value="<?php echo $category; ?>">
                    <option value="0" selected="selected">Select Category</option>
                    <option value="personal">Personal</option>
                    <option value="sports">Sports</option>
                    <option value="indoor-plants">Indoor Plants</option>
                    <option value="used-elec">Used Electronics</option>
                    <option value="used-cars">Used Cars</option>
                    <option value="dogs">Pure Breed Dog Adoption</option>
                </select>
			</td>
		</tr>
        <tr>
            <td></td>
            <td>
                <input type='submit' value='Save' class='btn btn-primary' />
                <input type='reset' value='Cancel' class='btn btn-primary' />
            </td>
        </tr>
    </table>
</form>