<?php
include 'header.php';
?>

<div class="container">
    <form class="form-inline d-flex justify-content-center md-form form-sm mt-0 mb-3" method="POST">
        <label>Find Results</label>
        <input class="form-control-sm ml-3 w-75 mr-2" name="search" type="text" placeholder="Search Products" aria-label="Search">
        <button class="btn btn-unique btn-rounded btn-sm my-0 btn-info bg-primary text-white" type="submit" name="search_text">Search</button>
    </form>
</div>
<div class='jumbotron'>
    <div class='container'>

        <table class='table table-hover'>
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Category</th> 
                <?php
                    //$search = $_POST['search'];
                    $text = file_get_contents('includes/data.inc.csv');
                    $lines = explode("\n", $text);
                    //if search field IS empty
                    if(empty($_POST['search'])){
                        echo "Please enter the items you want to search for.";
                    }// if search field is NOT empty
                    else if(isset($_POST['search'])){
                        $search = strtolower($_POST['search']);
                        // the following line prevents the browser from parsing this as HTML.
                        $file = 'includes/data.inc.csv';
                        // get the file contents, assuming the file to be readable (and exist)
                        $contents = strtolower(file_get_contents($file));
                        // escape special characters in the query
                        $pattern = preg_quote($search, '/');
                        // finalize the regular expression, matching the whole line
                        $pattern = "/^.*$pattern.*\$/m";
                        // search, and store all matching occurences in $matches
                        if (preg_match_all($pattern, $contents, $matches)){
                            echo '<tr>';
                            foreach ($matches[0] as $product){
                                $product_fields = implode(',', $matches[0]);
                                echo '<tr>';
                                foreach ($matches[0] as $filed){
                                    $result =  '<td>' . $filed .'</td>';
                                    echo $result;
                                }
                                echo '</tr>';
                            }
                        }else{
                            $result = "No matches found";
                            echo $result;
                        }
                    }
                ?>
            </tr>
        </table>
    </div>
</div>
