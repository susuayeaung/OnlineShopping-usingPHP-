<?php 
    include_once 'header.php';
?>
<section>
    <?php
        if(isset($_SESSION["useruid"])){
            echo "<p>Hello there " . $_SESSION["useruid"] . "</p>";
        }
    ?>
    <h1>Welcome to Classifieds</h1>
</section>

<div class="jumbotron bg-white">
    <main>
        <table class="table table-bordered table-hover">
            <tr>
                <td>
                    <div id="personal"><a href="personal.php? onClick1=true"><img src='imgCat/travel-pillow.png' /><figcaption>Personal</figcaption></a></div>
                </td>
                <td>
                    <div id="sports"><a href="sports.php? onClick2=true"><img src='imgCat/basketball.jpg' /><figcaption>Sports</figcaption></a></div>
                </td>
                <td>
                    <div id="plants"><a href="indoor-plants.php? onClick3=true"><img src='imgCat/chinese-evergreen.jpg' /><figcaption>Indoor Plants</figcaption></a></div>
                </td>
                <td>
                    <div id="electronics"><a href="used-elec.php? onClick4=true"><img src='imgCat/thinkpad.jpg' /><figcaption>Used Electronics</figcaption></a></div>
                </td>
                <td>
                    <div id="cars"><a href="used-cars.php? onClick5=true"><img src='imgCat/lexus.jpg' /><figcaption>Used Cars</figcaption></a></div>
                </td>
                <td>
                    <div id="dogs"><a href="dogs.php? onClick6=true"><img src='imgCat/labrador.jpg' /><figcaption>Pure Breed Dog Adoption</figcaption></a></div>
                </td>
            </tr>
        </table>
    </main>
</div>
<?php
defined('APPLICATION_PATH') || define('APPLICATION_PATH',realpath(dirname(__FILE__) . '/../includes'));
const DS = DIRECTORY_SEPARATOR;

require 'config/config.php';

//index.php?page=proeducts
$page  = get('page','home');
$model = '.php';
$view  = '.phtml';
$_404  = '404.phtml';

if(file_exists($model))
{
    require $model;
}
$main_content = $_404;
if(file_exists($view))
{
    $main_content = $view;
}

    include_once 'footer.php';
?>