<?php
include 'header.php';

if(isset($_GET['onClick1'])){
    $file = file("personal.csv");
    $newPer = fopen("newPer.csv", "w+");
    $header = $file[0];
    echo $header . "<br>";
    fwrite($newPer, $header);
    array_shift($file);
    sort($file);
    foreach($file as $line){
        echo $line . "<br>";
        fwrite($newPer, trim($line) . "\n");
    }
fclose($newPer);
}else if(isset($_GET['onClick2'])){
    $file = file("sports.csv");
    $newSp = fopen("newSp.csv", "w+");
    $header = $file[0];
    echo $header . "<br>";
    fwrite($newSp, $header);
    array_shift($file);
    sort($file);
    foreach($file as $line){
        echo $line . "<br>";
        fwrite($newSp, trim($line) . "\n");
    }
fclose($newSp);
}else if(isset($_GET['onClick3'])){
    $file = file("indoorPlants.csv");
    $newIp = fopen("newIp.csv", "w+");
    $header = $file[0];
    echo $header . "<br>";
    fwrite($newIp, $header);
    array_shift($file);
    sort($file);
    foreach($file as $line){
        echo $line . "<br>";
        fwrite($newIp, trim($line) . "\n");
    }
fclose($newIp);
}else if(isset($_GET['onClick4'])){
    $file = file("usedElectronics.csv");
    $newE = fopen("newE.csv", "w+");
    $header = $file[0];
    echo $header . "<br>";
    fwrite($newE, $header);
    array_shift($file);
    sort($file);
    foreach($file as $line){
        echo $line . "<br>";
        fwrite($newE, trim($line) . "\n");
    }
fclose($newE);
}else if(isset($_GET['onClick5'])){
    $file = file("usedCars.csv");
    $newC = fopen("newC.csv", "w+");
    $header = $file[0];
    echo $header . "<br>";
    fwrite($newC, $header);
    array_shift($file);
    sort($file);
    foreach($file as $line){
        echo $line . "<br>";
        fwrite($newC, trim($line) . "\n");
    }
fclose($newC);
}else if(isset($_GET['onClick6'])){
    $file = file("dogAdoption.csv");
    $newD = fopen("newD.csv", "w+");
    $header = $file[0];
    echo $header . "<br>";
    fwrite($newD, $header);
    array_shift($file);
    sort($file);
    foreach($file as $line){
        echo $line . "<br>";
        fwrite($newD, trim($line) . "\n");
    }
fclose($newD);
}
?>