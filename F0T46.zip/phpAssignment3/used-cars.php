<?php
include 'header.php';

if(isset($_GET['onClick5'])){
    include 'footer.php';
}
?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <th>Image</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Category</th>
            <th></th>
            <?php
                if(($fp = fopen("includes/used-cars.inc.csv", "r")) !== FALSE){
                    while(($fpd = fgetcsv($fp, 1000, ",")) !== FALSE){
                        $error = '';
                        $colcount = count($fpd);
                        echo'<tr>';
                        if($colcount != 5){
                            $error = 'Column count incorrect';
                        }else{
                            //check data types
                            if(!is_numeric($fpd[0])) $error.='error';
                            
                        }
                        switch($error){
                            case "Column count incorrect":
                                echo '<td></td>';
                                echo '<td></td>';
                                echo '<td>'.$error.'</td>';
                                echo '<td></td>';
                                echo '<td></td>';
                            break;

                            case "error":
                                echo '<td>'.$fpd[0].'</td>';
                                echo '<td>'.$fpd[1].'</td>';
                                echo '<td>'.$fpd[2].'</td>';
                                echo '<td>'.$fpd[3].'</td>';
                                echo '<td>'.$fpd[4].'</td>';
                            break;

                            default:
                                echo '<td>'.$fpd[0].'</td>';
                                echo '<td>'.$fpd[1].'</td>';
                                echo '<td>'.$fpd[2].'</td>';
                                echo '<td>'.$fpd[3].'</td>';
                                echo '<td>'.$fpd[4].'</td>';
                        }
                        echo '<td><input type="submit" value="Delete" href="delete.php" class="btn btn-primary" />
                            <input type="submit" value="Update" class="btn btn-primary" /></td>';
                        echo '</tr>';
                    }
                    fclose($fp);
                }
            ?>
        </table>
    </div>