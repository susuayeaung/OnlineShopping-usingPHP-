<?php

$fp = fopen("includes/data.inc.csv", "r");
if($fp){
    fclose($fp);
    header("Location:includes/data.inc.csv");
    exit;
}else{
    echo "Error deleting record";
}
