<?php

function invalidUid($username){
    $result = "";
    if(!preg_match("/^[a-zA-Z0-9]*$/", $username)){
        $result = true;
    }else{
        $result = false;
    }
    return $result;
}

function invalidEmail($email){
    $result = "";
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $result = true;
    }else{
        $result = false;
    }
    return $result;
}

function uidExists($fp, $username, $email){
    $fp = file('includes/signup.inc.csv');

    if(!array_key_exists($fp, $email, $username)){
        header("Location: ../signup.php?error=stmtfailed");
        exit();
    }

    $resultData = fgetcsv($fp, 1000, ",", "a+");

    if($row = $resultData){
        return $row;
    }else{
        $result = false;
        return $result;
    }
    fclose($fp);
}

function emptyInputLogin($username, $pwd){
    $result = "";
    if(empty($username) || empty($pwd)){
        $result = true;
    }else{
        $result = false;
    }
    return $result;
}

function loginUser($fp, $username, $pwd){
    $uidExists = uidExists($fp, $username, $username);
    if($uidExists === false){
        header("Location: ../login.php?error=wronglogin");
        exit();
    }
    $pwdHashed = $uidExists["usersPwd"]; //csv data to use inside code
    $checkPwd = password_verify($pwd, $pwdHashed); //checking if csv data password matches user input

    if($checkPwd === false){
        header("Location: ../login.php?error=wronglogin");
        exit();
    }else if($checkPwd === true){
        session_start();
        $_SESSION["userid"] = $uidExists["usersId"];
        $_SESSION["useruid"] = $uidExists["usersUid"];
        header("Location: ../index.php");
        exit();
    }
}

function get($name, $def = '')
{
	return $_REQUEST[$name] ?? $def;
}

function check_access()
{
	if (!isset($_SESSION['user_logged_in']) || !$_SESSION['user_logged_in'])
		header('Location: ?page=home');
}

function is_active($page,$current_link)
{
    return $page == $current_link ? 'active' : '';
}

function nextID(){
    global $config;
    $file_name = $config['DATA_PATH'] . 'id.txt';
    if(!file_exists($file_name)){
        touch($file_name);
        $handle = fopen($file_name,'r+');
        $id = 0;
    }
    else{
        $handle = fopen($file_name,'r+');
        $id = fread($handle,filesize($file_name));
        settype($id,"integer");
    }
    rewind($handle);
    fwrite($handle,++$id);
    fclose($handle);
    return $id;
}

function clean_text($string){
    $string = trim($string);
    $string = stripslashes($string);
    $string = htmlspecialchars($string);
    return $string;
}