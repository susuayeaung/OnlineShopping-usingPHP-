<?php
include 'functions.inc.php';

$error = '';
$name = '';
$description = '';
$price = '';
$category = '';


if(isset($_POST["submit"])){
    if(empty($_POST["name"])){
        $error .= '<p><label class="text-danger">Please Enter Product Name</label></p>';
    }else{
        $name = clean_text($_POST["name"]);
        if(!preg_match("/^[a-zA-Z]*$/",$name)){
            $error .= '<p><label class="text-danger">Only letters and white space allowed</label></p>';
        }
    }
    if(empty($_POST["description"])){
        $error .= '<p><label class="text-danger">Please Enter a Description of the Product</label></p>';
    }else{
        $description = clean_text($_POST["description"]);
        if(!preg_match("/^[a-zA-Z0-9]*$/",$description)){
            $error .= '<p><label class="text-danger">Only letters and white space allowed</label></p>';
        }
    }
    if(empty($_POST["price"])){
        $error .= '<p><label class="text-danger">Price is required</label></p>';
    }else{
        $price = clean_text($_POST["price"]);
    }
    if(empty($_POST["category"])){
        $error .= '<p><label class="text-danger">Category is required</label></p>';
    }else{
        $category = clean_text($_POST["category"]);
    }
    if($error == ''){
        $fp = fopen("data.inc.csv", "r");
        $no_rows = count(file("data.inc.csv"));
        if($no_rows > 1){
            $no_rows = ($no_rows - 1) + 1;
        }
        $form_data = array(
            'sr_no'  => $no_rows,
            'name'  => $name,
            'description'  => $description,
            'price' => $price,
            'category' => $category
        );
        fputcsv($fp, $form_data);
        $error = '<label class="text-success">Product has been added</label>';
        $name = '';
        $description = '';
        $price = '';
        $category = '';
    }
}
