<?php

if(isset($_POST["submit"])){
    $username = $_POST["uid"];
    $pwd = $_POST["pwd"];

    require_once 'login.inc.csv';
    require_once 'functions.inc.php';

    if(emptyInputLogin($username, $pwd) !== false){
        header("Location: ../login.php?error=emptyinput");
        exit();
    }else{
        $fp = fopen("signup.inc.csv", "a");
        $no_rows = count(file("includes/login.inc.csv"));
        if($no_rows > 1){
            $no_rows = ($no_rows - 1) + 1;
        }
        $form_data = array(
            'username' => $username,
            'email' => $email,
            'password' => $pwd
        );
        fgetcsv($fp);
    }
    loginUser($fp, $username, $pwd);
}else{
    header("Location: ../login.php");
    exit();
}