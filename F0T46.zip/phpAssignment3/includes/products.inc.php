<?php

$current_view = 'products.inc.php';
$file = 'includes/data.inc.csv';

switch (get('action')){
    case 'search':{
        $view = $current_view . 'search.pro.php';
        $products = file($file);
        break;
    }
    case 'view':{
        $view = $current_view . 'view.pro.phtml';
        $products = file($file);
        break;
    }
    case 'delete':{
        $view = $current_view . 'delete.pro.phtml';
        $id = get('id');
        $products = file($file);
        foreach ($products as $index => $product) {
            $fileds = explode(',',$product);
            if ($fileds[0] == $id) {
                    unset($products[$index]);
                    break;
            }
        }
        file_put_contents($file,implode('',$products));
        header('location: /?page=products&action=search');

        break;
    }
    case 'update':{
        $view = $current_view . 'update.pro.phtml';
        $products = file($file);
        $id = get('id');
        $product_to_update = '';
        foreach ($products as $index => $product) {
            $fileds = explode(',',$product);
            if ($fileds[0] == $id) {
                $product_to_update = $fileds;
                break;
            }
        }
        break;
    }
    case 'doUpdate':{
        $id = get('id');
        $updated_product = $id . ',' . get('make') . ',' . get('img') . ','. get('name') .',' . get('des') . ','. get('price'). ','. get('category'). PHP_EOL;
        $products = file($file);
        foreach ($products as $index => $product) {
            $fileds = explode(',',$product);
            if ($fileds[0] == $id) {
                $products[$index] = $updated_product;
                break;
            }
        }

        file_put_contents($file,implode('',$products));
        header('location: /?page=products&action=view');
    }

    case 'add':{
        $view = $current_view . 'add.phtml';
        break;
    }
    case 'doAdd':{
        // $view = $curd_view_dir.'update.phtml';
        $new_product = nextID() . ',' . get('make') . ',' . get('img') . ',' . get('name') . ',' . get('des') . ','. get('price') .','. get('category'). PHP_EOL;
        $products = file($file);
        array_push($products,$new_product);
        file_put_contents($file,implode('' , $products));
        header('location: /?page=products&action=view');
        break;
    }
}

