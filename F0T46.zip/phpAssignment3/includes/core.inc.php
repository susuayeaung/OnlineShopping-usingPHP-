<?php

error_reporting(E_ALL);

$page = isset($_GET['page']) ? $_GET['page'] : 1; //is the current page, if there's nothing set, default is home page

$records_per_page = 6;

$from_record_num = ($records_per_page * $page) - $records_per_page;