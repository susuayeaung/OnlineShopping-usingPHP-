<?php

$config = [
    'INCLUDES_PATH' => APPLICATION_PATH . DS. 'includes' . DS,
    'PRODUCTS_PATH' => APPLICATION_PATH . DS. 'products' . DS,
    'CONFIG_PATH' => APPLICATION_PATH . DS. 'config' . DS,
    '404' => APPLICATION_PATH . DS. '404' . DS,
];

require 'includes/functions.inc.php';