<h1>Update Product</h1>
<?php if(is_array($car_to_update)):?>
<form action="/?page=products&action=doUpdate" method="POST">
    Name:<input type="text" name="name" value="<?php echo $product_to_update[1];?>">
    Image:<input type="text" name="img" value="<?php echo $product_to_update[4];?>"><br>
    Description:<input type="text" name="desc" value="<?php echo $product_to_update[2];?>"><br>
    Price:<input type="text" name="price" value="<?php echo $product_to_update[3];?>"><br>
    Category:<input type="text" name="category" value="<?php echo $product_to_update[4];?>"><br>
    <input type="hidden" name="id" value="<?php echo $product_to_update[0];?>">
    <input type="submit">
</form>
<?php else:?>
    <h1>Cannot find product</h1>
<?php endif; ?>


