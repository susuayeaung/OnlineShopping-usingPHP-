
<table class="table table-hover">
    <tr>
        <th>Name</th>
        <th>Image</th>
        <th>Description</th>
        <th>Price</th>
        <th>Category</th>
    </tr>
        <?php
            foreach ($products as $product) {
                $product_fileds = explode(',',$product);
                echo '<tr>';
                foreach ($product_fileds as $filed) {
                    echo '<td>' . $filed .'</td>';
                }
            
            }
        ?>
</table>